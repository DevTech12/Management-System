<?php

include '_dbconnect.php'

$showAlert = '<div class="alert alert-warning alert-dismissible fade show" role="alert">
<strong>Congratulation</strong>'. $name.' your Account is created.
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';
if ($_SERVER["REQUEST_METHOD"] == "POST"){
    include '_dbconnect.php';
    $addNo = $_POST['AddNo'];
    $name = $_POST['Name'];
    $surname = $_POST['sName'];
    $Fname = $_POST['fName'];
    $Mname = $_POST['mName'];
    $occupation = $_POST['Occu'];
    $dob = $_POST['dob'];
    $caste = $_POST['caste'];
    $age = $_POST['age'];
    $qualification = $_POST['qualification'];
    $address = $_POST['address'];

    $exitSql = "SELECT * FROM `student` WHERE `name` = $name AND `fName` = $Fname AND `sName` = $surname";
    $result = mysqli_query($conn, $exitSql);
    $rows = mysqli_num_rows($result);
    if ($rows>0){
        $showError = "You already a User";
    }
    else {
            $sql = "INSERT INTO `student` (`AddNo`, `name`, `fName`, `sName`, `mName`, `Occupation`, `DOB`, `caste`, `age`, `address`, `qualification`, `cTime`) VALUES ($addNo, $name, $Fname, $surname, $Mname, $occupation, $dob, $caste, $age, $address, $qualification, current_timestamp())";
            $result = mysqli_query($conn, $sql);
            
            if ($result){
                $showAlert = true;
                header ("Location: /StudentMS/index.php?signupsuccess=true");
                exit();
            }
        }
        else {
            $showError = "Check your password";
            
        }
    header ("Location: /StudentMS/index.php?signupsuccess=false&error=$showError");
}
?>